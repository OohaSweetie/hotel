package com.java.exception;

public class FlightException extends Exception {
	public FlightException(String message){
		super(message);
	}
}
