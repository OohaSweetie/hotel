package com.java.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.java.dto.Flight;
import com.java.dto.UserDetails;
import com.java.service.FlightServiceImpl;

@WebServlet("/searchFlights")
public class FlightController extends HttpServlet{

	FlightServiceImpl service = new FlightServiceImpl();
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		try {
			UserDetails user = setUserDetails(req);
			List<Flight> flights = service.fetchFlights(user);
			PrintWriter writer = resp.getWriter();
			displayFlights(flights, writer);
		} catch (Exception e) {
			resp.sendError(404, e.getMessage());
		}
	}
	
	private UserDetails setUserDetails(HttpServletRequest req) {
		UserDetails user = new UserDetails();
		user.setJourney(req.getParameter("journey"));
		user.setFromStation(req.getParameter("fromStation"));
		user.setToStation(req.getParameter("toStation"));
		user.setFromDate(LocalDate.parse(req.getParameter("dateOfTravel")));
		return user;
	}

	private void displayFlights(List<Flight> flights, PrintWriter writer) {
		writer.println("<html><body>");
		writer.println("<H1>Flights Searched</H1><br>");
		writer.println("<h3>Name Of the Flight</h3> &nbsp; <h3>Fare</h3> &nbsp; <h3>Seats Left</h3>");
		for(Flight flight : flights){
			writer.println(flight.getName() + "&nbsp");
			writer.println(flight.getFare() + "&nbsp");
			writer.println(flight.getTotalSeats() - flight.getSeatsBooked() + "<br>");
		}
		writer.println("</body></html>");		
	}
}
