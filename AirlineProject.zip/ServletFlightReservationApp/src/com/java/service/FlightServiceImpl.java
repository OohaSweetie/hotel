package com.java.service;

import java.util.List;

import com.java.dao.FlightDAOImpl;
import com.java.dto.Flight;
import com.java.dto.UserDetails;
import com.java.exception.FlightException;

public class FlightServiceImpl implements FlightService{

	@Override
	public List<Flight> fetchFlights(UserDetails details) throws FlightException {
		FlightDAOImpl dao = new FlightDAOImpl();
		return dao.fetchFlights(details);
	}
}
