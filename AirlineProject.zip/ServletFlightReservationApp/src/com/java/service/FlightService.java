package com.java.service;

import java.util.List;

import com.java.dto.Flight;
import com.java.dto.UserDetails;
import com.java.exception.FlightException;

public interface FlightService {
	public List<Flight> fetchFlights(UserDetails details) throws FlightException;
}
