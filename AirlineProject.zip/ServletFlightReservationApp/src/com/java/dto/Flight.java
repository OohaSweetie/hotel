package com.java.dto;

import java.time.LocalDate;

public class Flight {
	private String name;
	private int totalSeats;
	private int seatsBooked;
	private float fare;
	private LocalDate dateofFlight;
	private String fromStation;
	private String toStation;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	public int getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(int seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public float getFare() {
		return fare;
	}

	public void setFare(float fare) {
		this.fare = fare;
	}

	public LocalDate getDateofFlight() {
		return dateofFlight;
	}

	public void setDateofFlight(LocalDate dateofFlight) {
		this.dateofFlight = dateofFlight;
	}

	public String getFromStation() {
		return fromStation;
	}

	public void setFromStation(String fromStation) {
		this.fromStation = fromStation;
	}

	public String getToStation() {
		return toStation;
	}

	public void setToStation(String toStation) {
		this.toStation = toStation;
	}

	@Override
	public String toString() {
		return "Flight [name=" + name + ", totalSeats=" + totalSeats
				+ ", seatsBooked=" + seatsBooked + ", fare=" + fare
				+ ", dateofFlight=" + dateofFlight + ", fromStation="
				+ fromStation + ", toStation=" + toStation + "]";
	}
}
