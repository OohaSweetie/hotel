package com.java.dao;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.java.exception.FlightException;

public class DbUtil {
	static Connection connection;
	
	public static Connection getConnection() throws FlightException{
		try {
			InitialContext context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:/OracleDS");
			connection = dataSource.getConnection();		
			return connection;
		} catch (Exception e) {
			throw new FlightException("Failed to Connect to the DB!");
		}
	}
}
