package com.java.dao;

import java.util.List;

import com.java.dto.Flight;
import com.java.dto.UserDetails;
import com.java.exception.FlightException;

public interface FlightDAO {
	public List<Flight> fetchFlights(UserDetails details) throws FlightException;
}
