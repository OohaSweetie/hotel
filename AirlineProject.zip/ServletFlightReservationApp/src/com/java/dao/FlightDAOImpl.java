package com.java.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.java.dto.Flight;
import com.java.dto.UserDetails;
import com.java.exception.FlightException;

public class FlightDAOImpl implements FlightDAO {

	@Override
	public List<Flight> fetchFlights(UserDetails details) throws FlightException {
		try {
			List<Flight> flights = new ArrayList<>();
			Connection con = DbUtil.getConnection();
			String sql = "SELECT * FROM FLIGHTS WHERE FROMSTATION = ? AND TOSTATION = ? AND DATEOFFLIGHT = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, details.getFromStation());
			ps.setString(2, details.getToStation());
			ps.setDate(3, Date.valueOf(details.getFromDate()));
			ResultSet rs = ps.executeQuery();
			
			while (rs.next()) {
				Flight flight = new Flight();
				flight.setName(rs.getString("name"));
				flight.setFare(rs.getFloat("fare"));
				flight.setDateofFlight(rs.getDate("dateofflight").toLocalDate());
				flight.setSeatsBooked(rs.getInt("seatsbooked"));
				flight.setTotalSeats(rs.getInt("totalseats"));
				flights.add(flight);
			}
			return flights;
		
		} catch (Exception e) {
			throw new FlightException(e.getMessage());
		}
	}
}
