package com.java.filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

@WebFilter("/searchFlights")
public class DateCheckFilter implements Filter {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		PrintWriter writer = res.getWriter();

		String travelDate = req.getParameter("dateOfTravel");
		LocalDate trvdate = LocalDate.parse(travelDate);

		String returnDate = req.getParameter("dateOfReturn");
		LocalDate retDate = LocalDate.parse(returnDate);

		LocalDate currentDate = LocalDate.now();

		String journeyType = req.getParameter("journey");
		if (journeyType.equalsIgnoreCase("return") && returnDate == "") {
			writer.println("Please select the return date!!!");
		} else if (retDate.isBefore(trvdate)) {
			writer.println("You cannot return to past man!!!");
		} else if (retDate.isBefore(currentDate)) {
			writer.println("You cannot return to past man!!! Really!!");
		} else {
			chain.doFilter(req, res);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}

}
