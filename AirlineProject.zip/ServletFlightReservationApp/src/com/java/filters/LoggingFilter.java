package com.java.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;

import org.apache.log4j.PropertyConfigurator;

@WebFilter(urlPatterns = "{/searchFlights}", initParams = { @WebInitParam(name = "path", value = "/WEB-INF/log4j.properties") })
public class LoggingFilter implements Filter {

	org.apache.log4j.Logger logger = org.apache.log4j.Logger
			.getLogger(LoggingFilter.class);

	@Override
	public void init(FilterConfig config) throws ServletException {
		String contextPath = config.getServletContext().getRealPath("/");
		String path = contextPath + config.getInitParameter("path");
		PropertyConfigurator.configure(path);
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws IOException, ServletException {
		try {
			logger.info("Booking Details:::::" + "Ticket Type: "
					+ req.getParameter("journey") + " , From Station: "
					+ req.getParameter("fromStation") + ", To Station: "
					+ req.getParameter("toStation") + ", Date of Travel: "
					+ req.getParameter("dateOfTravel") + ", Date of Return: "
					+ req.getParameter("dateOfReturn") + " No of Adults: "
					+ req.getParameter("noOfAdults") + ", No of Childrens: "
					+ req.getParameter("noOFChild"));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}
}
