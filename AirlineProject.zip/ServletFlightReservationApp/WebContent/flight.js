function validate(){
	var oneWay = document.getElementById("oneWay").selected;
	if (oneWay) {
		document.getElementById("dateOfReturn").setAttribute("disabled", "disabled");
	}else if (document.getElementById("return").selected) {
		document.getElementById("dateOfReturn").removeAttributeNS("disabled");
	}
	return true;
}