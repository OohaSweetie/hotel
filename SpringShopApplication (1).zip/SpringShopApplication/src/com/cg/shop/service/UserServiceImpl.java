package com.cg.shop.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.shop.dao.Userdao;
import com.cg.shop.dto.User;
@Service("productservice")
@Transactional
public class UserServiceImpl implements UserService {
    @Autowired
	Userdao userdao;
	
	@Override
	public void addUserDetails(User us) {
		// TODO Auto-generated method stub
		userdao.addUserDetails(us);
	}

	@Override
	public User showUserDetails(int id) {
		// TODO Auto-generated method stub
		return userdao.showUser(id);
	}

	@Override
	public boolean validUserDetails(User us) {
		return userdao.validUserDetails(us);
	}

	
}
