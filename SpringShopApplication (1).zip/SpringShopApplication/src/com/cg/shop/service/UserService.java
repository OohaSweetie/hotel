package com.cg.shop.service;
import com.cg.shop.dto.User;




public interface UserService {

	public void addUserDetails(User us);
	public User showUserDetails(int id);
	public boolean validUserDetails(User us);
}
