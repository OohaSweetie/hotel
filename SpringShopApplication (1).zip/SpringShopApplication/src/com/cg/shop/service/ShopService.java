package com.cg.shop.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.shop.dao.IShopDao;
import com.cg.shop.dao.ShopDao;
import com.cg.shop.dto.ProductDetail;

@Service("service")
@Transactional
public class ShopService implements IShopService
{
	@Autowired
	IShopDao dao=new ShopDao();
	
	@Override
	public void addProduct(ProductDetail pd)
	{
		dao.addProduct(pd);	
	}

	@Override
	public List<ProductDetail> showAllProduct()
	{
		return dao.showAllProduct();
	}

	@Override
	public ProductDetail searchProduct(int id)
	{
		return dao.searchProduct(id);
	}

	@Override
	public void deleteProduct(ProductDetail pd)
	{
		dao.deleteProduct(pd);
	}

	@Override
	public void updateProduct(ProductDetail pd)
	{
		dao.updateProduct(pd);
	}
	
}
