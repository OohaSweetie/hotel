package com.cg.shop.dao;


import com.cg.shop.dto.User;

public interface Userdao {
	public void addUserDetails(User us);
	public User showUser(int id);
	public boolean validUserDetails(User us);
}
