package com.cg.shop.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.shop.dto.User;
@Repository("productdao")
public class UserDaoImpl implements Userdao {
    @PersistenceContext
	private EntityManager entitymanager;

	@Override
	public void addUserDetails(User us) {
		// TODO Auto-generated method stub
		entitymanager.persist(us);
		entitymanager.flush();
	}

	@Override
	public User showUser(int id) {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("FROM User where userId=:id");
		query.setParameter("id", id);
		return (User) query.getSingleResult();
	}

	@Override
	public boolean validUserDetails(User us) {
		boolean res=true;
		Query query=entitymanager.createQuery("FROM User where userId=:id and password=:pwd");
		query.setParameter("id", us.getUserId());
		query.setParameter("pwd", us.getPassword());
		System.out.println(us.getUserId());
		System.out.println(us.getPassword());
		User user;
		try {
			user = (User) query.getSingleResult();
		} catch (Exception e) {
			res=false;
		}
		return res;
		
	}

	
	
	/*@Override
	public void addProduct(User pro) {
		// TODO Auto-generated method stub
		entitymanager.persist(pro);
		entitymanager.flush();
	}

	@Override
	public List<User> showAllProducts() {
		Query query=entitymanager.createQuery("FROM Products");
		return query.getResultList();
	}

	@Override
	public User searchProduct(int id) {
		Query queryOne=entitymanager.createQuery
				("FROM Products where productId=:productId");
		queryOne.setParameter("productId",id);
		User pro=(User) queryOne.getSingleResult();
		
		return pro;
	}

	@Override
	public void updateProduct(User pro) {
		// TODO Auto-generated method stub
		Query queryOne=entitymanager.createQuery
				("FROM Products where productId=:productId");
		queryOne.setParameter("productId",pro.getProductId());
		List<User> proList=queryOne.getResultList();
		for(User prol:proList)
		{
			prol.setPrice(pro.getPrice());
			prol.setBrand(pro.getBrand());
			prol.setCatagory(pro.getCatagory());
			
			entitymanager.persist(prol);
			entitymanager.flush();
	}
	}
*/
}
