package com.cg.shop.dao;

import java.util.List;

import com.cg.shop.dto.ProductDetail;


public interface IShopDao
{
	public void addProduct(ProductDetail pd);
	public List<ProductDetail> showAllProduct();
	public ProductDetail searchProduct(int id);
	public void deleteProduct(ProductDetail pd);
	public void updateProduct(ProductDetail pd);
}
