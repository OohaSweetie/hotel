package com.cg.shop.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.shop.dto.ProductDetail;

@Repository("dao")
@Transactional
public class ShopDao implements IShopDao
{
	@PersistenceContext
	EntityManager em;
	@Override
	public void addProduct(ProductDetail pd) 
	{
		em.persist(pd);
		em.flush();
	}

	@Override
	public List<ProductDetail> showAllProduct()
	{
		Query query=em.createQuery("FROM ProductDetail");
		return query.getResultList();
	}

	@Override
	public ProductDetail searchProduct(int id) {
		Query query=em.createQuery("FROM ProductDetail where id=:id");
		query.setParameter("id", id);
		ProductDetail pd=(ProductDetail) query.getSingleResult();
		return pd;
	}

	@Override
	public void deleteProduct(ProductDetail pd) {
		Query query=em.createQuery("FROM ProductDetail where id=:id");
		query.setParameter("id", pd.getId());
		ProductDetail pds=(ProductDetail) query.getSingleResult();
		em.remove(pds);
		em.flush();
	}

	@Override
	public void updateProduct(ProductDetail pd) {
		/*Query query=em.createQuery("FROM ProductDetail where id=:id");
		query.setParameter("id",pd.getId());
		ProductDetail pds=(ProductDetail) query.getSingleResult();
		pds.setBrand(pd.getBrand());
		pds.setPrice(pd.getPrice());
		pds.setCategory(pd.getCategory());
		em.persist(pds);*/
		em.merge(pd);
		em.flush();
	}
	
}
