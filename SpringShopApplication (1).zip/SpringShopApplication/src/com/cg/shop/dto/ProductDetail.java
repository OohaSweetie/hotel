package com.cg.shop.dto;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class ProductDetail {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
Integer id;
@NotEmpty(message="Name should not empty")
String name;
@NotNull(message="Price will not be empty")
Integer price;
@NotEmpty(message="Brand should not empty")
String brand;
@NotEmpty(message="Category should not empty")
String category;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getPrice() {
	return price;
}
public void setPrice(Integer price) {
	this.price = price;
}
public String getBrand() {
	return brand;
}
public void setBrand(String brand) {
	this.brand = brand;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}

}
