 package com.cg.shop.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.shop.dto.ProductDetail;
import com.cg.shop.dto.User;
import com.cg.shop.service.IShopService;
import com.cg.shop.service.ShopService;
import com.cg.shop.service.UserService;

@Controller
public class ShopController
{
	@Autowired
	IShopService service;
	@Autowired
	UserService userservice;
	
	@RequestMapping(value="/getuser",method=RequestMethod.GET)
	public String myUser(@ModelAttribute("my") User us){
		return "registration";
		
	}
	@RequestMapping(value="/adduser",method=RequestMethod.POST)
	public ModelAndView addUserDataBase(
			@Valid@ModelAttribute("my") User us,
			BindingResult result){
		int id=us.getUserId();
		System.out.println(id);
		if(result.hasErrors()){
			
			
			return new ModelAndView("addproducts");
		}
		userservice.addUserDetails(us);
		return new ModelAndView("welcome","user",us);
		
	}
	@RequestMapping(value="/showuser",method=RequestMethod.GET)
   public ModelAndView showAllData(@RequestParam("id")int id){
		System.out.println("aa gaya bhai aa gaya"+id);
   User users=userservice.showUserDetails(id);
	return new ModelAndView("welcome","us",users);
	
}
	
	@RequestMapping(value="/loginpage",method=RequestMethod.GET)
	public String loginUser(@ModelAttribute("myy") User us){
		return "login";
	
	
}
	@RequestMapping(value="/loginuser",method=RequestMethod.POST)
	public ModelAndView loginUserDataBase(
			@ModelAttribute("myy") User us){
		System.out.println(us.getPassword());
		boolean res=userservice.validUserDetails(us);
		if(res)
		{
			return new ModelAndView("welcome","user",us);
		}

		return new ModelAndView("Error");
		
	}
	@RequestMapping(value="/getProduct",method=RequestMethod.GET)
	public String myEmployee(@ModelAttribute("product") ProductDetail pd,
			Map<String,Object> model){
		List<String> myQul=new ArrayList<String>();
		myQul.add("Home");
		myQul.add("Electronics");
		myQul.add("Furniture");
		model.put("myp",myQul);
		return "InsertProduct";
		
	}
	@RequestMapping(value="/addProduct",method=RequestMethod.POST)
	public String addEmployeeDataBase(
			@Valid@ModelAttribute("product") ProductDetail pd,
			BindingResult result
			,Map<String,Object> model
			){

		if(result.hasErrors()){
			
			List<String> myQul=new ArrayList<String>();
			myQul.add("Home");
			myQul.add("Electronics");
			myQul.add("Furniture");
			model.put("myp",myQul);
			return "InsertProduct";
		}
		service.addProduct(pd);
		return "Success";
		
	}
	@RequestMapping(value="/showall",method=RequestMethod.GET)
   public ModelAndView showAllData()
	{
		List<ProductDetail> pList=service.showAllProduct();
		return new ModelAndView("show","pdata",pList);
	}
	
	/*@RequestMapping(value="/UpdateOne",method=RequestMethod.GET)
	public String showSingle(@RequestParam("id")int id)
	{
		System.out.println(id);
		//return "Update";	
	}*/
	@RequestMapping(value="/UpdateOne",method=RequestMethod.GET)
	public ModelAndView getSingleEmployee
	(@ModelAttribute("products")ProductDetail pd , @RequestParam("id")int id,Map<String,Object> model) {
		ProductDetail pds=service.searchProduct(id);
		List<String> myQul=new ArrayList<String>();
		myQul.add("Home");
		myQul.add("Electronics");
		myQul.add("Furniture");
		model.put("myp",myQul);
		return new ModelAndView("Update","productdata",pds);
		
	}
	@RequestMapping(value="/DeleteOne",method=RequestMethod.GET)
	public ModelAndView deleteSingleEmployee
	(@ModelAttribute("products")ProductDetail pd , @RequestParam("id")int id,Map<String,Object> model) {
		ProductDetail pds=service.searchProduct(id);
		return new ModelAndView("Delete","productdata",pds);
		
	}
	@RequestMapping(value="/delete",method=RequestMethod.POST)
	public ModelAndView deleteSingleEmployee
	(@Valid@ModelAttribute("products") ProductDetail pd) {
		service.deleteProduct(pd);
		return new ModelAndView("Success");
	}
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public ModelAndView updateSingleEmployee
	(@Valid@ModelAttribute("products") ProductDetail pd,BindingResult result) {
		service.updateProduct(pd);
		return new ModelAndView("Success");
	}
}