package com.mindtree.hotelreservation.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "registered_users")
public class RegisteredUser {
	@Id
	private int id;
	@Column(name = "user_name")
	private String userName;
	@Column(name = "email_id")
	private String mailId;
	@Column(name = "password")
	private String password;
	//@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	//private List<Reservation> reservations;

	public RegisteredUser() {
		super();
	}

	public RegisteredUser(String userName, String mailId, String password) {
		super();
		this.userName = userName;
		this.mailId = mailId;
		this.password = password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/*public List<Reservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<Reservation> reservations) {
		this.reservations = reservations;
	}*/

}
