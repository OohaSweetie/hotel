package com.cg.dto;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;
	import javax.validation.constraints.NotNull;


	@Entity
	@Table(name="springuser")
	public class User {
		
		@Id
		@NotNull(message="Id field will not be empty")
		private int userId;
		@NotNull(message="Name should not be empty")
		private String username;
		@NotNull(message="Password should not be empty")
		private String password;
		private String useraddress;
		private String userphone;
		private String gender;
		private String emailid;
		public int getUserId() {
			return userId;
		}
		public void setUserId(int userId) {
			this.userId = userId;
		}
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getUseraddress() {
			return useraddress;
		}
		public void setUseraddress(String useraddress) {
			this.useraddress = useraddress;
		}
		public String getUserphone() {
			return userphone;
		}
		public void setUserphone(String userphone) {
			this.userphone = userphone;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getEmailid() {
			return emailid;
		}
		public void setEmailid(String emailid) {
			this.emailid = emailid;
		}
		
		
	
}
