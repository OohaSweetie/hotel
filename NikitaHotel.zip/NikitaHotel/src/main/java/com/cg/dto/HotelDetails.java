package com.cg.dto;

	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
	import javax.persistence.Table;
	import javax.validation.constraints.NotNull;

@Entity
public class HotelDetails {
	
	


		
		@Id
		@NotNull(message="Id field will not be empty")
		private int hotelId;
		@NotNull(message="Name should not be empty")
		private String hotelName;
		private String roomType;
		private String hotelCity;
		private String hotelContact;
		private String amount;
		public int getHotelId() {
			return hotelId;
		}
		public void setHotelId(int hotelId) {
			this.hotelId = hotelId;
		}
		public String getHotelName() {
			return hotelName;
		}
		public void setHotelName(String hotelName) {
			this.hotelName = hotelName;
		}
		public String getRoomType() {
			return roomType;
		}
		public void setRoomType(String roomType) {
			this.roomType = roomType;
		}
		public String getHotelCity() {
			return hotelCity;
		}
		public void setHotelCity(String hotelCity) {
			this.hotelCity = hotelCity;
		}
		public String getHotelContact() {
			return hotelContact;
		}
		public void setHotelContact(String hotelContact) {
			this.hotelContact = hotelContact;
		}
		public String getAmount() {
			return amount;
		}
		public void setAmount(String amount) {
			this.amount = amount;
		}
		
		
		

}
