package com.cg.service;

import java.util.List;

import com.cg.dto.BookingDetails;
import com.cg.dto.HotelDetails;
import com.cg.dto.User;
import com.cg.exception.HotelException;

public class HotelService implements IHotelService{

	public List<HotelDetails> viewHotelList() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	public User validLogin() throws HotelException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean registerUser(User user) throws HotelException {
		// TODO Auto-generated method stub
		return false;
	}

	public int bookHotel(BookingDetails bookingDetails) throws HotelException {
		// TODO Auto-generated method stub
		return 0;
	}

}