package com.cg.service;

import java.util.List;

import com.cg.dto.BookingDetails;
import com.cg.dto.HotelDetails;
import com.cg.dto.User;
import com.cg.exception.HotelException;

public interface IHotelService {
	public List<HotelDetails> viewHotelList() throws HotelException;
	public User validLogin() throws HotelException;
	public boolean registerUser(User user) throws HotelException;
	public int bookHotel(BookingDetails bookingDetails) throws HotelException;
	}