package com.cg.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.User;
import com.cg.exception.HotelException;
import com.cg.service.HotelService;
import com.cg.service.IHotelService;

@Controller
public class HotelController {
	
@Autowired
	IHotelService service;
	@Autowired
	HotelService hotelservice;

	@RequestMapping(value="/getuser",method=RequestMethod.GET)
	public String myUser(@ModelAttribute("my") User us){
		return "registration"; 	
	}
	
	@RequestMapping(value="/adduser",method=RequestMethod.POST)
	public ModelAndView addUserDataBase(
			@Valid@ModelAttribute("my") User us,
			BindingResult result) throws HotelException{
	int id=us.getUserId();
	System.out.println(id);
	if(result.hasErrors()){
	
		
			return new ModelAndView("Registration");
		}
	hotelservice.viewHotelList();
	return new ModelAndView("search","user",us);
	
	}
	
	@RequestMapping(value="/loginpage",method=RequestMethod.GET)
	public String loginUser(@ModelAttribute("myy") User us){
		System.out.println("Login PAge:");
		return "login";

	
}
	/*@RequestMapping(value="login")
	public void loginUserDataBase() {
		System.out.println("welocme to spring ");
			}
	@RequestMapping(value="/")
	public void getBaseURL(){
		System.out.println("welocme to spring 1");
			}
	*/
	
		
	

}
