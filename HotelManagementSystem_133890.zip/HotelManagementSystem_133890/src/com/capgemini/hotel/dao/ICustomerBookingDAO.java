package com.capgemini.hotel.dao;
import com.capgemini.*;
import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelBookingException;
public interface ICustomerBookingDAO
{
	int addCustomerDetails(CustomerBean bean) throws HotelBookingException;
	RoomBooking getBookingDetails(int CustomerId);
	int addRoomDetails(RoomBooking room);
	public String getCustomerName(int custId);
}
