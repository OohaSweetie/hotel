package com.capgemini.hotel.dao;
import java.io.IOException;
import java.sql.*;

import org.apache.log4j.Logger;

import com.capgemini.*;
import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelBookingException;
import com.capgemini.hotel.utility.DatabaseConnection;
public class CustomerBookingDAO implements ICustomerBookingDAO
{
	Logger logger=Logger.getLogger(CustomerBookingDAO.class);
	@Override
	public int addRoomDetails(RoomBooking room)
	{
		try
		{
			int counter=0;
			Connection con=DatabaseConnection.getConnection();
			String selectQuery1="select * from RoomsDetail where roomno=?";
			PreparedStatement ps=con.prepareStatement(selectQuery1);
			ps.setInt(1, room.getRoomNo());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				counter++;
			}
			if(counter==0)
			{
				String insertQuery1="insert into RoomsDetail values(?,?,?)";
				ps=con.prepareStatement(insertQuery1);
				ps.setInt(1, room.getRoomNo());
				ps.setString(2, room.getRoomType());
				ps.setString(3, room.getStatus());
				int row=ps.executeUpdate();
				if(row==1)
				{
					return 1;
				}
				else
				{
					return 0;
				}
			}
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		return 0;
	}
	@Override
	public int addCustomerDetails(CustomerBean bean) throws HotelBookingException
	{
		try
		{
			//int mobileNo=Integer.parseInt(bean.getMobileNo());
			long mobileN=Long.parseLong(bean.getMobileNo());
			int roomNo=Integer.parseInt(bean.getRoomNo());
			Connection con=DatabaseConnection.getConnection();
			String insertQuery2="insert into CustomerDetails values(CustomerID_SEQ.nextval,?,?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(insertQuery2);
			ps.setString(1,bean.getCustName());
			ps.setString(2, bean.getEmail());
			ps.setString(3, bean.getCustAddress());
			ps.setLong(4, mobileN);
			ps.setString(5, bean.getRoomType());
			ps.setInt(6, roomNo);
			int row=ps.executeUpdate();
			if(row==1)
			{
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select CustomerID_SEQ.currval from dual");
				if(rs.next())
				{
					int custId=rs.getInt(1);
					logger.info("Customer Id : "+custId);
					return custId;
				}
			}
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			int errorCode=e.getErrorCode();
			if(errorCode==2291)
			{
				throw new HotelBookingException("Room No doesnt exist");
			}
			else
			{
				throw new HotelBookingException(e.getMessage());
			}
		}
		return 0;
	}

	@Override
	public RoomBooking getBookingDetails(int CustomerId)
	{
		RoomBooking room=new RoomBooking();
		try
		{
			Connection con=DatabaseConnection.getConnection();
			String selectQuery2="select roomno from CustomerDetails where custid=?";
			PreparedStatement ps=con.prepareStatement(selectQuery2);
			ps.setInt(1, CustomerId);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				int roomNum=rs.getInt(1);
				String selectQuery3="select roomno,roomtype,status from RoomsDetail where roomno=?";
				PreparedStatement ps1=con.prepareStatement(selectQuery3);
				ps1.setInt(1, roomNum);
				ResultSet rs1=ps1.executeQuery();
				if(rs1.next())
				{
					room.setRoomNo(rs1.getInt(1));
					room.setRoomType(rs1.getString(2));
					room.setStatus(rs1.getString(3));
					logger.info("Room details retrieved of Room Id:"+room.getRoomNo());
					return room;
				}
			}
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public String getCustomerName(int custId)
	{
		String custName;
		try
		{
			Connection con=DatabaseConnection.getConnection();
			String selectQuery3="select CustName from CustomerDetails where custid=?";
			PreparedStatement ps2=con.prepareStatement(selectQuery3);
			ps2.setInt(1, custId);
			ResultSet rs2=ps2.executeQuery();
			if(rs2.next())
			{
				custName=rs2.getString("custname");
				return custName;
			}
		}
		catch(SQLException e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
}
