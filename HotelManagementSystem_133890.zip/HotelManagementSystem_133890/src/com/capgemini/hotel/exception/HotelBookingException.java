package com.capgemini.hotel.exception;
public class HotelBookingException extends Exception
{

	public HotelBookingException()
	{
		super();
	}
	public HotelBookingException(String message)
	{
		super(message);
	}
}
