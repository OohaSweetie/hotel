package com.capgemini.hotel.service;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.*;
import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDAO;
import com.capgemini.hotel.dao.ICustomerBookingDAO;
import com.capgemini.hotel.exception.HotelBookingException;
public class HotelService implements IHotelService
{
	ICustomerBookingDAO dao;
	public HotelService()
	{
		dao=new CustomerBookingDAO();
	}
	@Override
	public int addCustomerDetails(CustomerBean bean) throws HotelBookingException
	{
		return dao.addCustomerDetails(bean);
	}
	@Override
	public String getCustomerName(int custId)
	{
		return dao.getCustomerName(custId);
	}
	@Override
	public RoomBooking getBookingDetails(int CustomerId)
	{
		return dao.getBookingDetails(CustomerId);
	}
	@Override
	public int addRoomDetails(RoomBooking room)
	{
		return dao.addRoomDetails(room);
	}
	@Override
	public boolean isValidName(String name)
	{
		String pattern="[A-Z][a-z]{4,20}";
		boolean res=Pattern.matches(pattern,name);
		return res;
	}
	@Override
	public boolean isValidPhone(String phone)
	{
		String pattern="[0-9]{10}";
		boolean res=Pattern.matches(pattern,phone);
		return res;
	}
	@Override
	public boolean isValidMailId(String mailid)
	{
		Pattern pattern=Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",Pattern.CASE_INSENSITIVE);
		Matcher matcher=pattern.matcher(mailid);
		if(matcher.find())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public boolean isValidRoomNo(String roomNo)
	{
		String pattern="[1-2]{1}[0]{1}[1-3]{1}";
		boolean res=Pattern.matches(pattern, roomNo);
		return res;
	}
	public boolean isValidRoomType(String roomType,String roomNo)
	{
		if(roomType.equals("AC_SINGLE")&&(roomNo.equals("101")||roomNo.equals("102")))
		{
			return true;
		}
		else if(roomType.equals("NONAC_SINGLE")&&(roomNo.equals("201")||roomNo.equals("202")))
		{
			return true;
		}
		else if(roomType.equals("AC_DOUBLE")&&roomNo.equals("103"))
		{
			return true;
		}
		else if(roomType.equals("NONAC_DOUBLE")&&roomNo.equals("203"))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	@Override
	public boolean isValidAddress(String address)
	{
		if((address.length()>4)&&(address.length()<25))
		{
			return true;
		}
		else
		{
			return false;
		}
			
	}
}
