package com.capgemini.hotel.service;
import com.capgemini.*;
import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelBookingException;
public interface IHotelService
{
	int addCustomerDetails(CustomerBean bean) throws HotelBookingException;
	RoomBooking getBookingDetails(int CustomerId);
	public String getCustomerName(int custId);
	public boolean isValidName(String name);
	public boolean isValidPhone(String phone);
	public boolean isValidMailId(String mailid);
	public boolean isValidRoomNo(String roomNo);
	public boolean isValidRoomType(String roomType,String roomNo);
	public boolean isValidAddress(String address);
	int addRoomDetails(RoomBooking room);
}
