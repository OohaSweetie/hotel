package com.capgemini.hotel.bean;
import com.capgemini.*;
public class RoomBooking
{
	private int roomNo;
	private String roomType;
	private String status="NOT BOOKED";
	public RoomBooking()
	{
		super();
	}
	public RoomBooking(int roomNo, String roomType, String status)
	{
		super();
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.status = status;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
