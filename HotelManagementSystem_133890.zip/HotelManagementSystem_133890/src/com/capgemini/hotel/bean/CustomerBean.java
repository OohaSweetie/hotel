package com.capgemini.hotel.bean;
import com.capgemini.*;
public class CustomerBean
{
	private int custID;
	private String custName;
	private String email;
	private String custAddress;
	private String mobileNo;
	private String roomType;
	private String roomNo;
	public CustomerBean()
	{
		super();
	}
	public CustomerBean(int custID, String custName, String email,
			String custAddress, String mobileNo, String roomType, String roomNo)
	{
		super();
		this.custID = custID;
		this.custName = custName;
		this.email = email;
		this.custAddress = custAddress;
		this.mobileNo = mobileNo;
		this.roomType = roomType;
		this.roomNo = roomNo;
	}
	public int getCustID() {
		return custID;
	}
	public void setCustID(int custID) {
		this.custID = custID;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
}
