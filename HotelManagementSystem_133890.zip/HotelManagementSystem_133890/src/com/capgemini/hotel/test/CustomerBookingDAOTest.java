package com.capgemini.hotel.test;
import org.junit.*;

import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.dao.CustomerBookingDAO;
import com.capgemini.hotel.dao.ICustomerBookingDAO;
import com.capgemini.hotel.exception.HotelBookingException;
import com.capgemini.hotel.service.HotelService;

public class CustomerBookingDAOTest
{
	@Test(expected=HotelBookingException.class)
	public void testInvalidAddress() throws HotelBookingException
	{
		CustomerBean cb=new CustomerBean();
		cb.setCustName("Niladri");
		cb.setCustAddress("abc");
		cb.setEmail("nilscot@gmail.com");
		cb.setMobileNo("8013324802");
		cb.setRoomNo("101");
		cb.setRoomType("AC_SINGLE");
		
		ICustomerBookingDAO dao=new CustomerBookingDAO();
		int id=dao.addCustomerDetails(cb);
		//Assert.assertTrue((id>0));
		
	}
}
