package com.capgemini.hotel.ui;
import com.capgemini.*;
import com.capgemini.hotel.bean.CustomerBean;
import com.capgemini.hotel.bean.RoomBooking;
import com.capgemini.hotel.exception.HotelBookingException;
import com.capgemini.hotel.service.HotelService;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
public class Client
{
	public static void main(String[] args) throws HotelBookingException
	{
		HotelService service=new HotelService();
		RoomBooking room=new RoomBooking();
		CustomerBean bean=new CustomerBean();
		Scanner sc=new Scanner(System.in);
		System.out.println("---Menu---");
		System.out.println("1) Book Room");
		System.out.println("2) View Booking Status");
		System.out.println("3) Exit");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:	do
				{
					System.out.println("Enter Customer Name:");
					String custName=sc.next();
					boolean res=service.isValidName(custName);
					if(res==true)
					{
						bean.setCustName(custName);
						break;
					}
					else
					{
						System.out.println("Invalid name, enter correct name");
					}
				}
				while(true);
				
				do
				{
					System.out.println("Enter Email\t:");
					String mailid=sc.next();
					boolean res=service.isValidMailId(mailid);
					if(res==true)
					{
						bean.setEmail(mailid);
						break;
					}
					else
					{
						System.out.println("Invalid email id");
					}
				}
				while(true);
				
				do
				{
					System.out.println("Enter Customer Address:");
					String custAddress=sc.next();
					boolean res=service.isValidAddress(custAddress);
					if(res==true)
					{
						bean.setCustAddress(custAddress);
						break;
					}
					else
					{
						System.out.println("Invalid Address");
					}
				}
				while(true);
				
				do
				{
					System.out.println("Enter Mobile No :");
					String mobileNo=sc.next();
					boolean res=service.isValidPhone(mobileNo);
					if(res==true)
					{
						bean.setMobileNo(mobileNo);
						break;
					}
					else
					{
						System.out.println("Invalid Mobile No");
					}
				}
				while(true);
				
				do
				{
					System.out.println("Room No :");
					String roomNo=sc.next();
					boolean res=service.isValidRoomNo(roomNo);
					if(res==true)
					{
						int roomNum=Integer.parseInt(roomNo);
						bean.setRoomNo(roomNo);
						room.setRoomNo(roomNum);
						break;
					}
					else
					{
						System.out.println("Invalid Room No");
					}
				}
				while(true);
				
				do
				{
					System.out.println("Room Type:");
					String roomType=sc.next();
					boolean res=service.isValidRoomType(roomType,bean.getRoomNo());
					if(res==true)
					{
						bean.setRoomType(roomType);
						room.setRoomType(roomType);
						room.setStatus("Booked");
						break;
					}
					else
					{
						System.out.println("Invalid Room Type");
					}
				}
				while(true);
				
				int roomNoBooked=service.addRoomDetails(room);
				if(roomNoBooked==0)
				{
					room.setStatus("Not Booked");
					System.out.println("This room is booked");
				}
				else
				{
					int custId=service.addCustomerDetails(bean);
					System.out.println("Your Room has been successfully booked, your Customer ID is:"+custId);
				}
				break;
		case 2: System.out.println("Enter Customer ID:");
				int custId=sc.nextInt();
				RoomBooking roomBooked=service.getBookingDetails(custId);
				String custName=service.getCustomerName(custId);
				if(custName==null)
				{
					System.out.println("No record for this customer ID");
				}
				else
				{
					System.out.println("Name of the Customer:"+custName);
					System.out.println("Booking Status:"+roomBooked.getStatus());
					System.out.println("Room No:"+roomBooked.getRoomNo());
					System.out.println("Room Type:"+roomBooked.getRoomType());
				}
		case 3:
				System.exit(0);
			
		default:System.out.println("Enter correct choice");
		}
	}

}
